# gps-sdr-sim-Windows

[GPS-SDR-SIM](https://github.com/osqzss/gps-sdr-sim) for Microsoft Windows

![MS Visual Studio 2017](gpssim_vs2017.png)

![gps-sdr-sim.exe](gpssim_exec.png)