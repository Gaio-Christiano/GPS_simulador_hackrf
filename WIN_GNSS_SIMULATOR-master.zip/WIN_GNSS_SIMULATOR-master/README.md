
WIN_GNSS_SIMULATOR

port "gps sdr sim" to windows and make it easy to use

* auto download Ephemeris file from server
* do not creat .bin file,but using buffer
* using hackrf to transfer gps sim signal in real-time under windows


![Start](https://github.com/crystalshark/WIN_GNSS_SIMULATOR/blob/master/img/1.jpg)
![Transfer](https://github.com/crystalshark/WIN_GNSS_SIMULATOR/blob/master/img/2.jpg)
